import numpy as np
import matplotlib.pyplot as plt
import os
from gillespie_exp_hypo_unif_algorithm import f_hypo

#B ~ Hipo(3) 1.7+2+1.3
lambdas = [1/1.7, 1/2,1/1.3]

def generar_B_hipoexponencial():
    B = sum(-1.0 / l * np.log(np.random.uniform()) for l in lambdas)
    return B

# Generar un gran número de muestras
num_muestras = 10000
muestras = [generar_B_hipoexponencial() for _ in range(num_muestras)]

x_vals = np.linspace(0, 30, 1000)
# Crear el histograma de las muestras
fig = plt.figure()
plt.hist(muestras, bins=50, density=True, alpha=0.6, color='b', label='Muestras')
plt.plot(x_vals, [f_hypo(x, lambdas) for x in x_vals], label='PDF Teórica', color='r')
plt.axvline(np.mean(muestras),color='green')

plt.xlabel('Valor de B')
plt.ylabel('Densidad')
plt.title('Histograma de Muestras de B')
plt.legend()
#plt.show()
plt.close()
directory = 'Desired_distributions'
if not os.path.exists(directory):
    os.makedirs(directory)
fig.savefig('Desired_distributions/FuenteB.png')
