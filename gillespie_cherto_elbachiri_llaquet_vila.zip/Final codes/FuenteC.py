import numpy as np
import matplotlib.pyplot as plt

# Función para generar C con distribución uniforme en [2, 8]
def generar_C_uniforme():
    return np.random.uniform(2, 8)

# Generar un gran número de muestras
num_muestras = 10000
muestras = [generar_C_uniforme() for _ in range(num_muestras)]

fig = plt.figure()
# Crear el histograma de las muestras
plt.hist(muestras, bins=30, density=True, alpha=0.6, color='g', label='Muestras')

# Dibujar la línea que representa la densidad de una distribución uniforme
plt.axhline(y=1/6, color='r', linestyle='-', label='Distribución Uniforme Teórica')

plt.xlabel('Valor de C')
plt.ylabel('Densidad')
plt.title('Histograma de Muestras vs Distribución Uniforme Teórica')
plt.legend()
#plt.show()
plt.close()
fig.savefig('Desired_distributions/FuenteC.png')
