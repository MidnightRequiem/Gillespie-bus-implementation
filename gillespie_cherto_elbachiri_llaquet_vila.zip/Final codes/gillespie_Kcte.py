import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
INF = 1e12


class Font:
    def __init__(self, name: str, memory: float, active: bool):
        self.name = name
        self.memory = memory
        self.active = active


def f_hypo(t, lambdas) -> float:
    f_value = 0
    prod_lambdas = np.prod(lambdas)
    for i in range(len(lambdas)):
        factor = prod_lambdas * np.exp(-lambdas[i]*t)
        for j in range(len(lambdas)):
            if i != j:
                factor *= 1 / (lambdas[j] - lambdas[i])
        f_value += factor
    return f_value


def R_hypo(t, lambdas) -> float:
    r_value = 0
    prod_lambdas = np.prod(lambdas)
    for i in range(len(lambdas)):
        factor = prod_lambdas/lambdas[i] * np.exp(-lambdas[i]*t)
        for j in range(len(lambdas)):
            if i != j:
                factor *= 1 / (lambdas[j] - lambdas[i])
        r_value += factor
    return r_value


def h_unif(t: float, a: float, b: float) -> float:
    if t < a: return 0
    elif a <= t <= b: return 1 / (b - t)
    else: return INF


def h(font: Font, t: float, rho: float, mu: float, K: float, lambdas: list, a: float, b: float):
    cum_t = t + font.memory
    if font.name == "A":  # Rate of client arrival in passengers/minutes  (exponential)
        return rho * mu * K
    if font.name == "B":  # Rate of bus arrival in passengers/minutes (hypo-exponential)
        return f_hypo(cum_t, lambdas) / R_hypo(cum_t, lambdas)
    else:                 # Uniform hazard function
        return h_unif(t=cum_t, a=a, b=b)


def gillespie(max_time: float, rho: float, mu: float, K: int, lambdas: list[float], a: float,
              b: float, seed: int, report_trace: bool) -> list:
    np.random.seed(seed)
    kwargs = {"rho": rho, "mu": mu, "K": K, "lambdas": lambdas, "a": a, "b": b}

    # System initialization
    fonts = [Font(name="A", memory=0.0, active=True),   # client generation
             Font(name="B", memory=0.0, active=True),   # bus generation
             Font(name="C", memory=0.0, active=False)]  # clients board the bus
    state = {"clients": 0, "capacity": 0}               # current state of the bus stop

    # Trace initialization
    trace = {0: {"time_start": 0, "delta_t": 0, "time_end": 0, "font_chosen": "Start", "clients": 0, "capacity": 0}}

    # Gillespie algorithm
    time_clock = 0
    transition = 1
    while time_clock < max_time:
        prev_state = state.copy()
        # print(f"Transition {transition}")
        # print("\t\t", [(font.name, font.memory, font.active) for font in fonts])
        u1, u2 = np.random.uniform(low=0, high=1, size=2)
        H = 0  # total hazard function
        for font in fonts:
            if font.active:
                H += h(font=font, t=0, **kwargs)
                # print(f"\t\t u1={u1}, h={h(font=font, t=0, **kwargs)}, H={H}")
        delta_t = - np.log(u1) / H  # compute delta_t with the inverse method

        # Select the transition to make
        cum_prob, selected_font = 0, None
        if fonts[2].active and delta_t > b:
            delta_t, selected_font = np.random.uniform(a, b), 2
        else:
            for i in range(len(fonts)):
                H1 = sum(h(font=font, t=delta_t, **kwargs) for font in fonts if font.active)
                if fonts[i].active:
                    h1 = h(font=fonts[i], t=delta_t, **kwargs)
                    cum_prob += h1/H1
                    # print(f"\t\t u2={u2}, H={H1}, cum_prob={cum_prob}, h1/H1={h1/H1}")
                    if cum_prob > u2 and selected_font is None:
                        selected_font = i

        if selected_font == 2 and delta_t < a:  # passenger boarding is uniform [a,b]
            delta_t = a

        for font in fonts:  # increment the memory of the active fonts
            if font.active:
                font.memory += delta_t
        fonts[selected_font].memory = 0  # reset the memory of the selected font

        # Implement the state change and activate/deactivate fonts
        if fonts[selected_font].name == "A":
            # A client arrives
            state["clients"] += 1
        elif fonts[selected_font].name == "B" and state["capacity"] == 0 and state["clients"] > 0:
            # A bus arrives and there are clients
            c = 3                   # generate the bus' capacity
            state["capacity"] = c   # change the current state
            fonts[2].active = True  # activate the possibility of boarding the bus ==> memory to 0
        elif fonts[selected_font].name == "C":
            # The clients can board the bus
            state["clients"] -= 1
            state["capacity"] -= 1
            if state["clients"] == 0:  # (0,m) state leads to (0,0) state
                state["capacity"] = 0
            if state["capacity"] == 0:  # There is no more capacity
                fonts[2].active = False  # Deactivate boarding the bus

        # Trace of the iteration
        trace[transition] = {"time_start": time_clock, "delta_t": delta_t, "time_end": time_clock + delta_t,
                             "font_chosen": fonts[selected_font].name,
                             "clients": state["clients"], "capacity": state["capacity"]}
        # print(f"delta_t = {round(delta_t*60, 2)}s, I={round(time_clock, 2)}min, prev_state={prev_state},"
        #      f"Transition={selected_font}, J={round(time_clock + delta_t, 2)}min, state={state}")
        time_clock += delta_t
        transition += 1

    # Save the trace
    trace = pd.DataFrame.from_dict(data=trace, orient="index")
    if report_trace: trace.to_csv(f"Traces\\gillespie_trace_c{K}_rho{rho}_seed{seed}.csv")

    # Basic measures
    L = np.sum(trace["delta_t"] * trace["clients"]) / time_clock
    L_var = np.sum(trace["delta_t"] * trace["clients"]**2) / time_clock - L**2

    l_index, r_index, W_list = 1, 1, []
    while r_index < len(trace):
        while l_index < len(trace) and trace.loc[l_index, "font_chosen"] != "A": l_index += 1
        while r_index < len(trace) and trace.loc[r_index, "font_chosen"] != "C": r_index += 1
        if max(l_index, r_index) < len(trace):
            W_list.append(trace.loc[r_index, "time_end"] - trace.loc[l_index, "time_end"])
            l_index += 1
            r_index += 1

    W, W_var = np.mean(W_list), np.var(W_list)
    return [trace, L, L_var, W, W_var]


def gillespie_plot(trace: pd.DataFrame, rho: float, K: int, seed: int):
    fig = plt.figure()
    plt.plot(trace["time_end"], trace["clients"], label="Number of clients in bus stop")
    plt.plot(trace["time_end"], trace["capacity"], label="Bus capacity")
    plt.legend()
    plt.title("Bus stop simulation")
    plt.xlabel("Time [min]")
    fig.savefig(f'Gillespie_plots/exp_hypo3_unif2-8_rho{rho}_K{K}_seed{seed}.png')
    plt.close()


if __name__ == "__main__":
    rhos = [0.3, 0.53333, 0.75, 0.9]      # load factors
    lambdas = [1/1.7, 1/2., 1/1.3]        # hypo-exponential rates
    mu = 1 / sum(1/lam for lam in lambdas)
    trace, L, L_var, W, W_var = gillespie(max_time=500*60, rho=rhos[0], mu=mu, K=3, lambdas=lambdas,
                                          a=2/60, b=8/60, seed=123, report_trace=True)
    print(f"Mean system occupation L = {L} passengers with variance {L_var}")
    print(f"Mean waiting time W = {W} minutes/passenger with variance {W_var}")
    # gillespie_plot(trace=trace, rho=rhos[0], K=3, seed=123)
