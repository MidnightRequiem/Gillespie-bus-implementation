from gillespie_exp_hypo_unif_algorithm import gillespie, gillespie_plot
import numpy as np
import pandas as pd
import dataframe_image as dfi
import os
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter


rhos = [0.3, 0.53333, 0.75, 0.9]  # load factors
lambdas = [1/1.7, 1/2., 1/1.3]  # hypo-exponential rates
mu = 1 / sum(1/lam for lam in lambdas)
K = 48
simulation_number = 12


def plot_W_hist(W_vect):
    counts, bins = np.histogram(W_vect)
    fig = plt.figure()
    percent = [i/sum(counts) for i in counts]
    counts, edges, bars = plt.hist(bins[:-1], bins, weights=percent)
    plt.gca().yaxis.set_major_formatter(PercentFormatter(1))
    # plt.bar_label(bars)
    plt.xlabel("Waiting time")
    plt.ylabel("Percentage of number of samples")
    # plt.show()
    directory = 'Results'
    if not os.path.exists(directory):
        os.makedirs(directory)
    fig.savefig(f'Results/Whist_rho{rho}_K{K}.png')
    plt.close()


if __name__ == "__main__":
    np.random.seed(123)
    random_seeds = np.random.randint(1, 100, simulation_number)

    true_rho_values = []  # to store 'rho' values for each simulation
    all_W_values_stand = []  # to store 'W' values for each simulation
    eB = 1 / mu
    varB = sum(1 / lam ** 2 for lam in lambdas)
    w0 = eB / 2 * (1 + varB / eB**2)

    for rho in rhos:
        W_complete_list = []
        sim_res = {'L': [], 'L_var': [], 'W': [], 'W_var': [], "Random seed": random_seeds}
        for sim in range(simulation_number):
            trace, L, L_var, W, W_var, W_list = gillespie(max_time=5*60, rho=rho, mu=mu, K=K, lambdas=lambdas, a=2/60,
                                                  b=8/60, seed=random_seeds[sim], report_trace=True)
            sim_res['L'].append(L)
            sim_res['L_var'].append(L_var)
            sim_res['W'].append(W)
            sim_res['W_var'].append(W_var)
            gillespie_plot(trace, rho, K, random_seeds[sim])
            W_complete_list += W_list

            filtered_trace_A = trace[trace['font_chosen'] == 'A']
            filtered_trace_B = trace[trace['font_chosen'] == 'B']
            mean_busCapacity = filtered_trace_B['capacity'].mean()

            true_rho = len(filtered_trace_A) / (len(filtered_trace_B) * mean_busCapacity)
            true_rho_values.append(true_rho)
            all_W_values_stand.append(W / w0)

        plot_W_hist(W_complete_list)
        df_rho = pd.DataFrame.from_dict(sim_res)
        dfi.export(df_rho, f'Results/Table_rho{rho}_K{K}.png', table_conversion='matplotlib')

    print("rhos", true_rho_values)
    # Plotting W values for all rhos
    plt.figure(figsize=(10, 6))
    plt.scatter(true_rho_values, all_W_values_stand, label='Standardized W values', alpha=0.5)
    plt.xlabel('Load factors (rho)')
    plt.ylabel('Standardized W Values')
    plt.title('W values for Different Load factors')
    plt.legend()
    plt.savefig('Results/W_rhos.png')
    plt.show()
