from gillespie_exp_hypo_unif_algorithm import gillespie
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression


if __name__ == "__main__":
    lambdas = [1/1.7, 1/2., 1/1.3]  # hypo-exponential rates
    mu = 1 / sum(1/lam for lam in lambdas)
    np.random.seed(123)
    n_sims = 12
    rand_seeds = np.random.randint(1, 100, n_sims).tolist()
    waiting_df = pd.DataFrame(np.nan, index=range(n_sims), columns=["mean_waiting_time", "mean_boarding_time"])
    for i in range(n_sims):
        trace, L, L_var, W, W_var, _ = gillespie(max_time=5*60, rho=0.53333, mu=mu, K=48, lambdas=lambdas,
                                              a=2/60, b=8/60, seed=rand_seeds[i], report_trace=False)
        l_index, r_index, boarding_waiting_list = 0, 0, []
        while r_index < len(trace):
            while l_index < len(trace) and trace.loc[l_index, "font_chosen"] != "A": l_index += 1
            while r_index < len(trace) and trace.loc[r_index, "font_chosen"] != "C": r_index += 1
            if max(l_index, r_index) < len(trace):
                m_index, found = r_index, False
                while l_index < m_index and not found:
                    m_index -= 1
                    if trace.loc[m_index, "font_chosen"] == "B" and trace.loc[m_index-1, "capacity"] == 0:
                        found = True
                boarding_waiting_list.append(trace.loc[r_index, "time_end"] - trace.loc[m_index, "time_end"])
                l_index += 1
                r_index += 1
        waiting_df.loc[i] = [W, np.mean(boarding_waiting_list)]

    corr_coef = np.corrcoef(waiting_df, rowvar=False)[0, 1]
    prev_var = np.var(waiting_df['mean_waiting_time'])
    next_var = np.var(waiting_df['mean_waiting_time']) * (1-corr_coef**2)
    print(f"Correlation is {corr_coef}")
    print(f"Variance moves from {round(prev_var, 5)} to {round(next_var, 5)}")
    print(f"Previous: W = {round(np.mean(waiting_df['mean_waiting_time']), 6)} +- " +
          f"{round(2.200985*np.sqrt(prev_var/(n_sims-1)), 6)}")
    print(f"Next: W = {round(np.mean(waiting_df['mean_waiting_time']), 6)} +- " +
          f"{round(2.200985 * np.sqrt(next_var/(n_sims - 1)), 6)}")

    lr = LinearRegression()
    lr.fit(np.array(waiting_df.loc[:, "mean_boarding_time"]).reshape(-1, 1),
           np.array(waiting_df.loc[:, "mean_waiting_time"]).reshape(-1, 1))

    fig = plt.figure()
    plt.xlabel("Mean boarding time")
    plt.ylabel("Mean waiting time")
    plt.scatter(waiting_df["mean_boarding_time"], waiting_df["mean_waiting_time"])
    plt.axline(xy1=(0, lr.intercept_[0]), slope=lr.coef_[0, 0], color="orange")
    plt.show()
