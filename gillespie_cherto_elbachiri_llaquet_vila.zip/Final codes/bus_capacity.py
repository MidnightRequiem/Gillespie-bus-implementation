from scipy.integrate import quad
from scipy.interpolate import interp1d
import numpy as np
import matplotlib.pyplot as plt

def pdf_teórica(c, K):
    """Función de densidad de probabilidad teórica."""
    a = 2 / (K * (np.exp(2) - 1))
    return a * np.exp(2 * (1 - c / K))

def cdf_teórica(c, K):
    """Función de distribución acumulativa teórica (CDF) calculada numéricamente."""
    # Integral de la PDF desde 0 hasta c
    result, _ = quad(lambda x: pdf_teórica(x, K), 0, c)
    return result

K = 48  # Capacidad máxima del autobús
c_vals = np.linspace(0, K, 1000)  # Definiendo c_vals

# Generar valores de la CDF para un rango de valores de c
cdf_vals = [cdf_teórica(c, K) for c in c_vals]

# Crear una función de interpolación para la CDF inversa
cdf_inversa = interp1d(cdf_vals, c_vals, fill_value="extrapolate")

def generar_muestra_cdf_inversa(K):
    # Generar un número aleatorio uniforme entre 0 y 1
    u = np.random.rand()
    # Obtener la capacidad correspondiente usando la CDF inversa
    return np.ceil(cdf_inversa(u))

num_muestras = 10000  # Número de muestras a generar
# Generar un nuevo conjunto de muestras utilizando la CDF inversa
muestras_cdf_inversa = [generar_muestra_cdf_inversa(K) for _ in range(num_muestras)]

# Crear el histograma de las nuevas muestras
fig = plt.figure()
plt.hist(muestras_cdf_inversa, bins=range(int(K)+1), density=True, alpha=0.6, color='b', label='Muestras CDF Inversa')
plt.plot(c_vals, [pdf_teórica(c, K) for c in c_vals], label='PDF Teórica', color='r')

plt.xlabel('Capacidad del autobús')
plt.ylabel('Densidad')
plt.title('Histograma de Muestras CDF Inversa vs PDF Teórica')
plt.legend()
#plt.show()
plt.close()
fig.savefig('Desired_distributions/BusCapacity.png')
